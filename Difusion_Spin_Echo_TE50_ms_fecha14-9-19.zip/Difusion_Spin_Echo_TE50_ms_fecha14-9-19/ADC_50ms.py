import numpy as np
from scipy.optimize import curve_fit
from scipy.special import erfc
from scipy import ndimage
import matplotlib.pyplot as plt
import matplotlib.image as mpimg
from mpl_toolkits.axes_grid1 import make_axes_locatable
import seaborn as sns
from shapely.geometry import Point
from shapely.geometry.polygon import Polygon
from scipy.signal import butter, lfilter, freqs
from mpl_toolkits.mplot3d import Axes3D
from matplotlib.collections import PolyCollection
from matplotlib import colors as mcolors
from matplotlib import cm
sns.set() # Seaborn es una libreria para graficar basada en MathPlotLib
FOV=16. #cm
N=32
def datos_temporales50():
	xdif=[0, 1.27, 1.28, 1.28, 1.32, 1.33, 1.32, 1.3, 1.3, 1.33, 1.7]#, 6.18]
	xdata=map(lambda h: sum(xdif[:h+1]),range(len(xdif)) )
	return xdata
def datos_temporales150():
	xdif=[0, 1.4, 1.3, 1.33, 1.25, 1.37, 1.42, 1.33, 1.32, 1.3, 1.28]#, 1.55, 2.03, 8.48]
	xdata=map(lambda h: sum(xdif[:h+1]),range(len(xdif)) )
	return xdata
def lee_imagenes(num_imag,T2):
	imag=[]
	for i in range(num_imag):
		fil=str(T2)+"_"+str(i)+".txt"
		with open(fil,"r") as x:
			imag.append([[ float(number) for number in line.split()] for line in x])
	return imag				
def semi_infinito(t, a, b, c):
	return   a*erfc(b/np.sqrt(t))+c
def semi_infinito_doble(t, a1, a2, b, c):
	return   a1*erfc(b/np.sqrt(t))+a2*erfc(b/np.sqrt(t))+c
def finito(t,a,b,c,d,e):
	return a*np.exp(-b*t)+c*np.exp(-d*t)+e
class regiones:
	def __init__(self,experimento):
		self.zonas=[]
		if experimento=="papa_cuadrada":
			self.zonas.append( [Polygon([(11.95,16.25),(15.1,12.6),(20.52,17.88),(17.75,21.35)]),"azucar"])
			self.zonas.append( [Polygon([(15.,7.7),(17.3,5.8),(27.96,15.3),(25.37,16.7)]),"agua abajo"])
			self.zonas.append( [Polygon([(5.5,11.9),(12.25,2.7),(14.59,4.6),(7.3,13.1)]),"agua costado1"])
			self.zonas.append( [Polygon([(21.3,24.64),(27.7,16.7),(29.55,18.17),(22.5,26.22)]),"agua costado2"])
			self.zonas.append( [Polygon([(8.57,14.45),(13.4,8.6),(25.52,17.88),(20.08,24.35)]),"papa"]) #Contiene la zona de azucar
		if experimento=="celofan":
			self.zonas.append( [Polygon([(11.65,29.6),(31.7,29.5),(31.7,23.7),(11.89,23.7)]),"agua"] )
			self.zonas.append( [Polygon([(13.1,22.45),(32.6,22.5),(32.52,19.88),(12.7,19.35)]),"azucar"]) #Contiene la zona de azucar
			self.zonas.append( [Polygon([(13.1,22.45),(11.89,23.7),(31.7,23.7),(32.6,22.5)]),"celofan"])
	def id_zona(self,x,y):
		point = Point(x, y)
		for i in range(len(self.zonas)):
			if self.zonas[i][0].contains(point):
				return self.zonas[i][1]
		return "fondo"
class imagen:
	def __init__(self,matriz,T2):
		self.data=np.matrix(matriz)
		self.max=np.amax(matriz)
		self.min=np.amin(matriz)
		self.size=len(matriz)
		self.T2=T2;
	def corta(self,x0,xf,y0,yf):
		aux=[]
		for i in range(y0,yf):
			aux.append(self.data.tolist()[i][x0:xf])
		return imagen(aux, self.T2)
	def grafica(self,scale,save,name):
		if scale:
			plt.imshow(self.data, cmap='jet', vmin = scale[0], vmax = scale[1])
		else:
			plt.imshow(self.data, cmap='jet', vmin = self.min, vmax = self.max)
		cbar = plt.colorbar()
		cbar.ax.tick_params(labelsize=10) 
		cbar.set_label('Cantidad de agua')
		if save:
			plt.savefig(name+".png", bbox_inches='tight')	
		plt.show()
	def interpola(self):
		x= [ [ (self.data.tolist()[i][j]+self.data.tolist()[i+1][j] +self.data.tolist()[i][j+1] + self.data.tolist()[i+1][j+1])/4. for i in range(0,self.size,2)] for j in range(0,self.size,2) ]
		return imagen(x, self.T2)
	def vertical(self):
		aux=self.data.transpose()
		return imagen(ndimage.rotate(np.matrix(aux),50.,reshape=False), self.T2)
	def zona(self,experimento,posx,posy):
		return regiones(experimento).id_zona(posx,posy)
	def zonas(self,experimento):
		return np.matrix([ [self.zona(experimento,i,j) for j in  range(len(self.data.tolist()[0]) )] for i in range(len(self.data.tolist()[0])) ] )
	def alturas(self):
		num_elements= map(lambda h: float(np.count_nonzero(h)),self.data.tolist())
		x=[]
		for i in range(len(num_elements)):
			if num_elements[i]==0:
				x.append(0)
				continue
			x.append(sum(self.data.tolist()[i])/num_elements[i])
		return np.array(x)

class imagenes:
	def __init__(self,matrices,tiempos,T2):
		self.imags=[]
		for i in range(len(matrices)):
			self.imags.append(imagen(matrices[i],T2))
		self.data= np.array([self.imags[i].data for i in range(len(self.imags))])
		self.max=(np.amax( [self.imags[i].data.max() for i in range(len(self.imags))] ))
		self.min=(np.amin( [self.imags[i].data.min() for i in range(len(self.imags))] ))
		self.tiempos=np.array(tiempos)
		self.popt=False
		self.size=len(matrices[0])
		self.mean= np.array([self.data[i].mean() for i in range(len(self.tiempos)) ])
		self.T2=T2;
	def corta(self,x0,xf,y0,yf):
		return imagenes([ self.imags[i].corta(x0,xf,y0,yf).data for i in range(len(tiempos)) ],self.tiempos, self.T2)
	def interpola(self):
		return imagenes([ self.imags[i].interpola().data for i in range(len(tiempos)) ],self.tiempos, self.T2)
	def escalea(self):
		return imagenes([self.data[i]/self.mean[i] for i in range(len(self.tiempos))] ,self.tiempos, self.T2)
	def verticales(self):
		return imagenes(  [ self.imags[i].vertical().data for i in range(len(self.tiempos))] ,self.tiempos, self.T2)
	def grafica(self,save,name,width,height):
		fig=plt.figure()
		for i in range(len(self.imags)):
			ax = fig.add_subplot(width,height,i+1)
			ax.hlines(17, 0, 32, colors='k', linestyles='dashed', label='celofan')
			ax.set_title(str(int(self.tiempos[i]))+" h",pad=0.5,fontsize=11)
			im=plt.imshow(self.imags[i].data, cmap='jet', vmin = self.min, vmax = self.max)
			plt.axis('off')
		cbar_ax = fig.add_axes([0.91, 0.145, 0.03, 0.7])
		fig.colorbar(im,cax=cbar_ax).ax.tick_params(labelsize=10)
		fig.colorbar(im,cax=cbar_ax).set_label('Cantidad de agua')
		if save:
			plt.savefig(name+".png", bbox_inches='tight')	
		plt.show()
		return
	def ajuste(self,funcion,xpos,ypos,graph,save,name):
		print (xpos,ypos)
		xdata=self.tiempos
		ydata=np.array( map(lambda h: h.item((xpos,ypos)),self.data)  )
		if ydata.mean()<0.1:
			popt=[0.,0.,ydata.mean()]
		else:
			try:
				popt, pcov = curve_fit(funcion,xdata , ydata)
			except:
				popt=[0.,0.,ydata.mean()]
		plt.title('Ajuste',fontsize=16)
		plt.grid(True)
		plt.ylabel("Concentracion [u.a.]",fontsize=16)
		plt.xlabel("Tiempo [h]",fontsize=16)
		plt.plot(xdata,ydata,'ro')
		plt.plot(xdata,funcion(np.array(xdata),*popt),label='fit:')
		plt.legend(fontsize=12)
		if save:
			plt.savefig(name+".png", bbox_inches='tight')
		if graph:
			plt.show()
		plt.close()
		return popt
	def ajuste_perfil_singraf(self,funcion1,funcion2,alturas,hpos,graph,save,name):
		xdata=self.tiempos
		ydata=np.array( map(lambda h: h.item((hpos)),alturas) )
		#ydata=alturas
		#p0=[30000,0.1,500]
		#p0=[1,5,1]
		p0=[1.,0.5,1.]
		if hpos==16 or hpos==17 or hpos==18:
			p0=[1.,1.,0.5,1.]
			popt, pcov = curve_fit(funcion2,xdata,ydata,p0,bounds=((-5.,-5., 0., 0.), (5.,5., 2., 5.)))
		else:
			try:
				popt, pcov = curve_fit(funcion1,xdata,ydata,p0,bounds=((-5., 0., 0.), (5., 2., 5.)))
				#popt, pcov = curve_fit(funcion,xdata,ydata,p0,bounds=((0.,-5., 0.), (5., 5., 5.)))
			except:
				popt=[0.,0.,ydata.mean()]
		print(hpos)
		print(popt)
		return popt
	def ajuste_perfil(self,funcion1,funcion2,alturas,hpos,graph,save,name):
		xdata=self.tiempos
		ydata=np.array( map(lambda h: h.item((hpos)),alturas) )
		#ydata=alturas
		#p0=[30000,0.1,500]
		#p0=[1,5,1]
		p0=[1.,0.5,1.]
		if hpos==16 or hpos==17 or hpos==18:
			p0=[1.,1.,0.5,1.]
			popt, pcov = curve_fit(funcion2,xdata,ydata,p0,bounds=((-5.,-5., 0., 0.), (5.,5., 2., 5.)))
		else:
			try:
				popt, pcov = curve_fit(funcion1,xdata,ydata,p0,bounds=((-5., 0., 0.), (5., 2., 5.)))
				#popt, pcov = curve_fit(funcion,xdata,ydata,p0,bounds=((0.,-5., 0.), (5., 5., 5.)))
			except:
				popt=[0.,0.,ydata.mean()]
		print(hpos)
		print(popt)
		plt.title("Ajuste "+str(hpos),fontsize=16)
		plt.grid(True)
		plt.ylabel("Concentracion [u.a.]",fontsize=16)
		plt.xlabel("Tiempo [h]",fontsize=16)
		plt.plot(xdata,ydata,'ro')
		if hpos==16 or hpos==17 or hpos==18:
			plt.plot(xdata,funcion2(np.array(xdata),*popt),label='fit:')
		else:
			plt.plot(xdata,funcion1(np.array(xdata),*popt),label='fit:')
		plt.legend(fontsize=12)
		if save:
			plt.savefig(name+".png", bbox_inches='tight')
		if graph:
			plt.show()
		plt.close()
		return popt
	def ajuste_imagenes(self,funcion):
		self.popt=[ [self.ajuste(funcion,i,j,False,False,False) for i in range(self.size) ] for j in range(self.size)  ]
		return
	def ajuste_evaluado(self,funcion,tiempo,graph,save,name):
		if self.popt==False:
			self.ajuste_imagenes(funcion)
		fitted= imagen( [ [funcion(tiempo,*self.popt[i][j]) for i in range(self.size)] for j in range(self.size) ], self.T2 )
		if graph:
			fitted.grafica( [self.min,self.max],save,name)
		return fitted.data
	def ajustadas(self,funcion,graph,save,name,width,height):
		fitted=imagenes( [ self.ajuste_evaluado(funcion,self.tiempos[i],False,False,False) for i in range(len(tiempos)) ],self.tiempos, self.T2)
		if graph:
			fitted.grafica(save,name,width,height)
	def alturas(self,save,name,saltos):
		labels=[]
		posicion=[] # Posicion altura en mm
		plt.figure()
		alturas=[]
		colors = plt.cm.jet(np.linspace(0,1,len(self.tiempos)/saltos))
		for j in range(self.size):
			posicion.append(j*FOV/N)
		for i in range(0,len(self.tiempos),saltos):
			plt.plot(posicion,self.imags[i].alturas(),color=colors[(i-1)/saltos])
			labels.append(str(int(self.tiempos[i]))+' h')
			alturas.append(self.imags[i].alturas())
		plt.legend(labels, ncol=3, loc='center left', 
		   bbox_to_anchor=[-0.01, .895], 
		   columnspacing=1., labelspacing=0.0,
		   handletextpad=0.0, handlelength=1.5,
		   fancybox=True, shadow=True)
		plt.ylabel("Cantidad de agua (u.a.)",fontsize=16)
		plt.xlabel("Posicion (mm)",fontsize=16)
		if save:
			plt.savefig(name+".png", bbox_inches='tight')
		plt.show()
		return np.array(alturas)
	def grafica_plana3d(self,save,name):
		fig = plt.figure()
		ax = fig.add_subplot(111, projection='3d')
		#ax = plt.axes(projection='3d')

		posicion=[] # Posicion altura en mm
		for j in range(self.size):
			posicion.append(j*FOV/N)
		x = posicion
		y = self.tiempos
		X,Y = np.meshgrid(x,y)
		Z = np.zeros((len(y),len(x)))

		for i in range(len(y)):
			Z[i]=self.imags[i].alturas()
		#ax.plot_surface(X, Y, Z, rstride=1, cstride=1000, color='w', shade=False, lw=.5)
		ax.plot_surface(X, Y, Z, rstride=1, cstride=1000, color='b', edgecolors='k', shade=True, lw=1, alpha=0.5)
		#ax.plot_surface(X, Y, Z, rstride=1, cstride=1, lw=0, antialiased=False)
		

		
		ax.set_xlabel("Posicion (mm)",fontsize=16)
		ax.set_zlabel("Tiempo (h)",fontsize=16)
		ax.set_zlabel("Cantidad de agua (u.a.)",fontsize=16)
		ax.view_init(70,-70)
		if save:
			plt.savefig(name+".png", bbox_inches='tight')
		plt.show()

	def grafica3d(self,save,name):
		fig = plt.figure()
		ax = fig.add_subplot(111, projection='3d')
		#ax = plt.axes(projection='3d')

		posicion=[] # Posicion altura en mm
		for j in range(self.size):
			posicion.append(j*FOV/N)
		x = posicion
		y = self.tiempos
		X,Y = np.meshgrid(x,y)
		Z = np.zeros((len(y),len(x)))

		for i in range(len(y)):
			Z[i]=self.imags[i].alturas()
		#ax.plot_surface(X, Y, Z, rstride=1, cstride=1000, color='w', shade=False, lw=.5)
		ax.plot_surface(X, Y, Z, rstride=1, cstride=1, color='b', edgecolors='k', cmap=cm.coolwarm, shade=True, lw=0.5, antialiased=True, alpha=0.5)
		#ax.plot_surface(X, Y, Z, rstride=1, cstride=1, lw=0, antialiased=False)
		

		
		ax.set_xlabel("Posicion (mm)",fontsize=12)
		ax.set_ylabel("Tiempo (h)",fontsize=12)
		ax.set_zlabel("Cantidad de agua (u.a.)",fontsize=12)
		ax.view_init(72,-72)
		if save:
			plt.savefig(name+".png", bbox_inches='tight')
		plt.show()

	def integral_zonas(self,experimento,save,name):
		z=regiones(experimento)
		rdata=[]
		labels=map(lambda h: h[1],z.zonas)
		plt.ylabel("Concentracion [u.a.]",fontsize=16)
		plt.xlabel("Tiempo [h]",fontsize=16)
		for j in range(len(self.tiempos)):
			ydata=[]
			x=self.imags[j].zonas(experimento)
			for i in range(len(z.zonas)):
				ydata.append( np.where(x==z.zonas[i][1],self.imags[j].data,0.).sum() )
			rdata.append(ydata)
		rdata=np.matrix(rdata).transpose()
		for i in range(len(z.zonas)):
			plt.plot(self.tiempos,np.array(rdata.tolist()[i])/np.array(rdata.tolist()[i]).max())
		plt.legend(labels, ncol=2, loc='upper left', 
		   bbox_to_anchor=[0.5, 1.1], 
		   columnspacing=1.0, labelspacing=0.0,
		   handletextpad=0.0, handlelength=1.5,
		   fancybox=True, shadow=True)
		if save:
			plt.savefig(name+".png", bbox_inches='tight')
		plt.show()
		return			
	def grafica_zonas(self,graph,save,name,experimento):
		plt.imshow(self.data[-1], cmap='jet', vmin = self.min, vmax = self.max)
		z=regiones(experimento)
		for i in range(len(z.zonas)):
			x,y = z.zonas[i][0].exterior.xy
			plt.plot(x,y,color='black')
		cbar = plt.colorbar()
		cbar.ax.tick_params(labelsize=10) 
		cbar.set_label('Cantidad de agua')
		if save:
			plt.savefig(name+".png", bbox_inches='tight')
		if graph:
			plt.show()
	def polinomio(self,grado,graph,save,name,posx,posy):
		ydata=np.array( map(lambda h: h.item((posx,posy)),self.data)  )
		poly =np.poly1d(np.polyfit(self.tiempos,ydata,grado))
		pol=np.polyder(poly)
		plt.title('Ajuste',fontsize=16)
		plt.grid(True)
		plt.ylabel("Concentracion [u.a.]",fontsize=16)
		plt.xlabel("Tiempo [h]",fontsize=16)
		plt.plot(self.tiempos,ydata,'ro')
		plt.plot(self.tiempos,poly(self.tiempos),label='fit')
		plt.plot(self.tiempos,pol(self.tiempos),label='derivada')
		plt.legend(fontsize=12)
		if save:
			plt.savefig(name+".png", bbox_inches='tight')
		if graph:
			plt.show()
		return poly




imags150=lee_imagenes(11,150)
tiempos150=datos_temporales150()
imags150=imagenes(imags150,tiempos150,150).verticales()

print(imags150.imags[1].size)

print(imags150.imags[1].size)

imags150=imags150.escalea()

imags50=lee_imagenes(11,50)
tiempos50=datos_temporales50()[0:11]
imags50=imagenes(imags50,tiempos50,50).verticales()

print(imags50.imags[1].size)


print(imags50.imags[1].size)

imags50=imags50.escalea()


print(imags50.T2)

print(imags150.T2)


h50=imags50.alturas(True,"Integrado_cantidad_de_agua_SE50ms",1)
pos=[]
variable=[]
width, height=4,5

plt.figure()
for i in range(12,27):
	popt=imags50.ajuste_perfil_singraf(semi_infinito,semi_infinito_doble,h50,i,True,True,"ajuste50_perfiles h="+str(i))
	if i==16 or i==17 or i==18:
		continue
		#variable.append(popt[2])
	else:
		variable.append(popt[1])
	pos.append(i*FOV/N)

plt.vlines(8.5,min(variable),max(variable),colors='k', linestyles='dashed', label='celofan')
plt.xlabel(r"$z^\prime$ (cm)",fontsize=16)
plt.ylabel(r"$B$ $(s^{-1/2})$",fontsize=16)


	
plt.plot(pos,variable,'ro')


def linear_fit(x, m, n):
	return x*m+n
p0_l=[0.4,1.,]
popt_l, pcov_l = curve_fit(linear_fit,pos,variable,p0_l)#,bounds=((-5.,-5., 0., 0.), (5.,5., 2., 5.)))

plt.plot(pos,linear_fit(np.array(pos),*popt_l))

labels=["Parametro obtenido",r"Ajuste lineal D=0.046(7) cm$^2$ s$^{-1}$", "Celofan"]

plt.legend(labels, ncol=1,fontsize=10)
"""
	, loc='upper left', 
		   bbox_to_anchor=[0.5, 1.1], 
		   columnspacing=1.0, labelspacing=0.0,
		   handletextpad=0.0, handlelength=1.5,
		   fancybox=True, shadow=True)
		   """



print(np.sqrt(np.diag(pcov_l))[0]/popt_l[0])

print("D*="+str(1./(4.*popt_l[0]*popt_l[0]*3600)))

plt.savefig("Ajuste_D.png", bbox_inches='tight')

plt.show()
