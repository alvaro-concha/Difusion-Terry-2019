import matplotlib.pyplot as plt
import numpy as np
import math
from scipy.optimize import curve_fit
import seaborn as sns
sns.set() # Seaborn es una libreria para graficar basada en MathPlotLib

########################################################################

T1, T2, m, error1, error2 = np.loadtxt("datos.txt", skiprows=1, unpack=True)
pp = [0.]
m2 = 255.39 # gramos de agua #.25539 # kg de agua
m1 = 0.

for i in range(1, m.size):
		m1 += m[i]
		pp.append(100.*m1/(m1+m2))

def f1(x, A1, B1):
	return A1*x+B1
def f2(x, A2, B2):
	return A2*x+B2
p1 = 2100., 0.8 # Inicializo parametros de ajuste
p2 = 2000., 0.8 # Inicializo parametros de ajuste

k1, cov1 = curve_fit(f1, pp, T1, p1)
sigma1 = np.sqrt(np.diag(cov1))
k2, cov2 = curve_fit(f2, pp, T2, p2)
sigma2 = np.sqrt(np.diag(cov2))

def plot1(x):
	return k1[0]*x+k1[1]
def plot2(x):
	return k2[0]*x+k2[1]
mplot = np.arange(0.0, 65., 5.)
	

fig1 = plt.figure(1)
ax1 = fig1.add_subplot(111)

ax1.errorbar(pp, T1, yerr=error1, ls="", color="dodgerblue", marker='o', ms=3)
ax1.errorbar(pp, T2, yerr=error2, ls="", color="orange", marker='*', ms=5)

ax1.plot(mplot, plot1(mplot), linestyle='--', color="dodgerblue", label=r"$T_1=T^0_1+\alpha_1 c$")
ax1.plot(mplot, plot2(mplot), linestyle='-.', color="orange", label=r"$T_2=T^0_2+\alpha_2 c$")
#ax1.set_xscale('log')
#ax1.set_yscale('log')
ax1.grid(color='grey', linestyle='-', linewidth=0.25, alpha=0.5)

ax1.set_xlabel(r'Concentracion $(\%p/p)$')
ax1.set_ylabel('Tiempo (ms)')
plt.legend()
fig1.show()

print(k1)
print(np.sqrt(np.diag(cov1)))

print(k2)
print(np.sqrt(np.diag(cov2)))

textstr = '\n'.join((
    r'$T^0_1=1990(60)$ ms',
    r'$\alpha_1=-32.4(1.6)$ ms $\%p/p^{-1}$',
    r'$T^0_2=2090(50)$ ms',
    r'$\alpha_1=-33.3(1.4)$ ms $\%p/p^{-1}$'))

# these are matplotlib.patch.Patch properties
#props = dict(boxstyle='round', facecolor='wheat', alpha=0.5)
props = dict(boxstyle='round', facecolor='white', alpha=0.5)

# place a text box in upper left in axes coords
#ax1.text(0.05, 0.95, textstr, transform=ax1.transAxes, fontsize=14, verticalalignment='top', bbox=props)
ax1.text(0.58, 0.77, textstr, transform=ax1.transAxes, fontsize=10, verticalalignment='top', bbox=props)

fig1.savefig('Tiempo_concentracion_pp.png', bbox_inches='tight')

input() # python3, raw_input() python2, to keep figures alive
